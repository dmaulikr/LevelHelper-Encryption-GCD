//This header file was generated automatically by LevelHelper
//For more info please visit: www.gamedevhelper.com


#ifndef LH_USE_BOX2D
	#define LH_USE_BOX2D
#endif
